<?php
include 'template/db.php';
session_start();
if(empty($_SESSION['login']) or $_SESSION['role'] != 3){
    header('location:./login.php');
    exit();
}
$id_user = $_SESSION['id_user'];
$sql_inj = "";
$date_from = "";
$date_to = "";
if(isset($_POST['uslugi_date_from']) && isset($_POST['uslugi_date_to'])){
    $date_from = $_POST['uslugi_date_from'];
    $date_to = $_POST['uslugi_date_to'];
    $sql_inj = " AND zapis.vremya_zapis >= '$date_from 00:00:00' AND zapis.vremya_zapis <= '$date_to 00:00:00' ";
}
$sql = "SELECT id_zapis, fio_client, vremya_zapis, name_uslugi 
FROM zapis, clients, uslugi 
WHERE zapis.id_client=clients.id_client 
AND zapis.id_uslugi=uslugi.id_uslugi 
AND zapis.id_user=$id_user $sql_inj ORDER BY id_zapis";
$result=$mysqli->query($sql);
$trener = $result->fetch_all(MYSQLI_ASSOC);
include 'template/head.php';
include 'template/nav_trener.php';
?>
<div class="container" style="margin-top: 20px;">
    <div class="row">
    <h2 class="mb-4">Список проведенных тренировок за период </h2>
                <form action="trener.php" method="post">
                    <input type="date" name="uslugi_date_from" placeholder="С" value="<?= $date_from ?>">
                    <input type="date" name="uslugi_date_to" placeholder="По"  value="<?= $date_to ?>">
                    <input type="submit" value="Показать">
                </form>
        <div class="col-lg-1"></div>
        <div class="col-lg-10">
          <h3 style="text-align: center">Список проведенных треннеровок (<?= $_SESSION['login'] ?>)</h3> 
          <table class="table">
            <thead>
                <tr class="table-primary">
                    <th scope="col">№</th>
                    <th scope="col">ФИО Клиента</th>
                    <th scope="col">Дата</th>
                    <th scope="col">Вид тренеровки</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                    <?php 
                    if(!empty($trener)){
                        foreach ($trener as $row){
                        echo "
                            <tr>
                            <td>".$row['id_zapis']."</td>
                            <td>".$row['fio_client']."</td>
                            <td>".$row['vremya_zapis']."</td>
                            <td>".$row['name_uslugi']."</td>
                            </tr>
                        ";
                        }
                    }
                    ?>    
            </tbody>
          </table> 
        </div>
        <div class="col-lg-1"></div>
    </div>
</div>
<?php include 'template/footer.php';?>
