<?php
include "template/db.php";
include "template/head.php";
$sql_inj = "";
$date_from = "";
$date_to = "";
session_start();
if(empty($_SESSION['login']) or $_SESSION['role'] != 2){
    header('location:./login.php');
    exit();
}
if(isset($_POST['uslugi_date_from']) && isset($_POST['uslugi_date_to'])){
    $date_from = $_POST['uslugi_date_from'];
    $date_to = $_POST['uslugi_date_to'];
    $sql_inj = " WHERE zapis.vremya_zapis >= '$date_from 00:00:00' AND zapis.vremya_zapis <=  '$date_to 00:00:00' ";
}
$sql = "SELECT * FROM zapis, clients, uslugi 
WHERE zapis.id_client = clients.id_client 
AND zapis.id_uslugi = uslugi.id_uslugi $sql_inj ORDER BY id_zapis";
$result = $mysqli->query($sql);
$zapis = $result->fetch_all(MYSQLI_ASSOC);
?>
    <!-- <script src="js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script> -->
    <?php
    include 'template/nav_registrator.php';
    ?>
    <main class="container">

    
        <section class = "report">
            <div class="report__title">
                <h2 class="mb-4">Отчет по работе тренажерного зала за период</h2>
                <form action="registrator.php" method="post">
                    <input type="date" name="uslugi_date_from" placeholder="С" value="<?= $date_from ?>">
                    <input type="date" name="uslugi_date_to" placeholder="По"  value="<?= $date_to ?>">
                    <input type="submit" value="Показать">
                </form>
                <table class="table table-hover mt-4">
                    <thead>
                        <tr>
                            <th>
                                <h3>№</h3>
                            </th>
                            <th>
                                <h3>Ф.И.О клиента</h3>
                            </th>
                            <th>
                                 <h3>Количество услуг</h3>
                            </th>
                            <th>
                                <h3>Дата оплаты</h3>
                            </th>
                            <th>
                                <h3>Сумма</h3>
                            </th>                           
                        </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($zapis as $zapiska) { ?>
                        <tr>
                            <td><?= $zapiska['id_zapis']?></td>
                            <td><?= $zapiska['fio_client']?></td>
                            <td><?= $zapiska['uslugi_number']?></td>
                            <td><?= $zapiska['vremya_zapis']?></td>
                            <td><?= $zapiska['price_usluigi']*$zapiska['uslugi_number']?></td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </section>
    
    </main>
<?php include 'template/footer.php';?>
