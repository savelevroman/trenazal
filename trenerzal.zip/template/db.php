<?php
$mysqli=new mysqli ("localhost", "root", "","trenazal"); 
$mysqli->set_charset("utf8"); 
?>