<div class="container-fluid" style="background-color: #00008b; color: white; padding-top: 20px; padding-bottom: 20px; margin-top: 20px">
    <div class="row">
        <div class="col-lg-1"></div>
        <div class="col-lg-10" style="text-align: center">
        <p>&copy2024 Все права защищены<br>Разработано студентами группы В-4 Краснов Андрей, Савельев Роман, Шевченко Данила</p>
        </div>
        <div class="col-lg-1"></div>
    </div>
</div>