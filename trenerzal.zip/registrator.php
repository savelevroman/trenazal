<?php
include "template/db.php";
include "template/head.php";
include "template/nav.php";
?>
