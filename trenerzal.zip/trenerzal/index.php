
<?php
include 'template/head.php';
include 'template/nav.php';
?>
<div class="row">
    <div class="col-2"></div>
    <div class="col-10 text-center">
        <h3>Тренажерный зал</h3>
    </div>
    <div class="col-2"></div>
</div>