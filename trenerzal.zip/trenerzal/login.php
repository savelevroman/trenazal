<?php
    session_start();
    if (!empty($_POST['login']) and !empty($_POST['password'])) {
        require "./template/db.php";
        $login = $_POST['login'];
        $password = $_POST['password'];
        $sql = "SELECT * FROM users WHERE login = '$login' AND password = '$password'";
        $result = $mysqli->query($sql);
        $user = $result->fetch_assoc();
        print '<pre>';
        print_r($user);
        print '</pre>';
        if($user){            
            $_SESSION['role'] = $user['role']; 
            $_SESSION['id_user'] = $user['id_user'];
            if($user['role'] == 1){
                header('location: ./director.php');
            }
        } else {
            $error = "Проверьте данные";
        }

    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <script src="js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <?php
            include 'template/head.php';
            include 'template/nav.php';
        ?>
    <main>
        <section class = "login">
        <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <h3 class="text-center mt-5">Login</h3>
                <form action="login.php" method="post">
                    <?php
                    if(isset($error)){
                    ?>
                    <div class="alert alert-danger" role="alert">
                       <?= $error ?>
                    </div>
                    <?php } ?>
                    <div class="mb-3">
                        <label for="login" class="form-label">Login</label>
                        <input type="text" class="form-control" name="login" id="login" placeholder="Enter login" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="rememberMe">
                        <label class="form-check-label" for="rememberMe">Remember me</label>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </div>
        </section>
    </main>
</body>
</html>